package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType {
    DEPOSIT,
    HOUSE_RENT,
    AUNTY_BILL,
    UTILITY_BILL
}

enum class PaymentStatus {
    PAID,
    CHECKED,
    DUE
}

enum class AppLanguage {
    BENGALI,
    ENGLISH
}

enum class AppThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

@Entity(tableName = "mess_transactions")
data class MessTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: TransactionType,
    val amount: Double,
    val year: Int,
    val month: Int, // 1..12
    val day: Int,   // 1..31
    val timestampMillis: Long,
    val title: String,
    val note: String = "",
    val status: PaymentStatus = PaymentStatus.PAID
)

@Entity(tableName = "daily_meals")
data class DailyMeal(
    @PrimaryKey val dateKey: Int, // YYYYMMDD e.g. 20261124
    val year: Int,
    val month: Int,
    val day: Int,
    val breakfast: Double = 0.0,
    val lunch: Double = 0.0,
    val dinner: Double = 0.0,
    val note: String = "",
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    val totalMeals: Double
        get() = breakfast + lunch + dinner

    companion object {
        fun makeDateKey(year: Int, month: Int, day: Int): Int =
            year * 10000 + month * 100 + day
    }
}

data class MonthSummary(
    val year: Int,
    val month: Int,
    val totalDeposit: Double,
    val totalHouseRent: Double,
    val totalAuntyBill: Double,
    val totalUtilityBill: Double,
    val totalMonthlyExpense: Double,
    val totalMeals: Double,
    val mealDaysCount: Int
) {
    companion object {
        fun calculate(
            year: Int,
            month: Int,
            transactions: List<MessTransaction>,
            meals: List<DailyMeal>
        ): MonthSummary {
            val totalDeposit = transactions
                .filter { it.type == TransactionType.DEPOSIT }
                .sumOf { it.amount }
            val totalHouseRent = transactions
                .filter { it.type == TransactionType.HOUSE_RENT }
                .sumOf { it.amount }
            val totalAuntyBill = transactions
                .filter { it.type == TransactionType.AUNTY_BILL }
                .sumOf { it.amount }
            val totalUtilityBill = transactions
                .filter { it.type == TransactionType.UTILITY_BILL }
                .sumOf { it.amount }

            val totalMonthlyExpense = totalDeposit + totalHouseRent + totalAuntyBill + totalUtilityBill
            val totalMeals = meals.sumOf { it.totalMeals }
            val mealDaysCount = meals.count { it.totalMeals > 0.0 }

            return MonthSummary(
                year = year,
                month = month,
                totalDeposit = totalDeposit,
                totalHouseRent = totalHouseRent,
                totalAuntyBill = totalAuntyBill,
                totalUtilityBill = totalUtilityBill,
                totalMonthlyExpense = totalMonthlyExpense,
                totalMeals = totalMeals,
                mealDaysCount = mealDaysCount
            )
        }
    }
}
