package com.example.data.repository

import com.example.data.local.MessDao
import com.example.data.model.DailyMeal
import com.example.data.model.MessTransaction
import kotlinx.coroutines.flow.Flow

class MessRepository(private val dao: MessDao) {
    fun observeTransactionsForMonth(year: Int, month: Int): Flow<List<MessTransaction>> =
        dao.observeTransactionsForMonth(year, month)

    fun observeMealsForMonth(year: Int, month: Int): Flow<List<DailyMeal>> =
        dao.observeMealsForMonth(year, month)

    suspend fun saveTransaction(transaction: MessTransaction) {
        if (transaction.id == 0L) {
            dao.insertTransaction(transaction)
        } else {
            dao.updateTransaction(transaction)
        }
    }

    suspend fun deleteTransaction(id: Long) {
        dao.deleteTransactionById(id)
    }

    suspend fun saveMeal(meal: DailyMeal) {
        if (meal.totalMeals <= 0.0 && meal.note.isBlank()) {
            dao.deleteMealByDateKey(meal.dateKey)
        } else {
            dao.upsertMeal(meal.copy(updatedAtMillis = System.currentTimeMillis()))
        }
    }

    suspend fun getMealForDate(year: Int, month: Int, day: Int): DailyMeal? {
        return dao.getMealByDateKey(DailyMeal.makeDateKey(year, month, day))
    }

    suspend fun deleteMeal(dateKey: Int) {
        dao.deleteMealByDateKey(dateKey)
    }
}
