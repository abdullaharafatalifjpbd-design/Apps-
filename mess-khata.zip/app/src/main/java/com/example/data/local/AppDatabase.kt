package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.data.model.DailyMeal
import com.example.data.model.MessTransaction
import com.example.data.model.PaymentStatus
import com.example.data.model.TransactionType

class MessTypeConverters {
    @TypeConverter
    fun fromTransactionType(type: TransactionType): String = type.name

    @TypeConverter
    fun toTransactionType(value: String): TransactionType =
        enumValues<TransactionType>().firstOrNull { it.name == value } ?: TransactionType.UTILITY_BILL

    @TypeConverter
    fun fromPaymentStatus(status: PaymentStatus): String = status.name

    @TypeConverter
    fun toPaymentStatus(value: String): PaymentStatus =
        enumValues<PaymentStatus>().firstOrNull { it.name == value } ?: PaymentStatus.PAID
}

@Database(
    entities = [MessTransaction::class, DailyMeal::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(MessTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messDao(): MessDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mess_khata_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
