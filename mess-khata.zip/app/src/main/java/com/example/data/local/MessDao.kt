package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DailyMeal
import com.example.data.model.MessTransaction
import kotlinx.coroutines.flow.Flow

@Dao
interface MessDao {
    @Query("SELECT * FROM mess_transactions WHERE year = :year AND month = :month ORDER BY day DESC, timestampMillis DESC")
    fun observeTransactionsForMonth(year: Int, month: Int): Flow<List<MessTransaction>>

    @Query("SELECT * FROM mess_transactions ORDER BY year DESC, month DESC, day DESC, timestampMillis DESC")
    fun observeAllTransactions(): Flow<List<MessTransaction>>

    @Query("SELECT * FROM daily_meals WHERE year = :year AND month = :month ORDER BY day DESC")
    fun observeMealsForMonth(year: Int, month: Int): Flow<List<DailyMeal>>

    @Query("SELECT * FROM daily_meals WHERE dateKey = :dateKey LIMIT 1")
    suspend fun getMealByDateKey(dateKey: Int): DailyMeal?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: MessTransaction): Long

    @Update
    suspend fun updateTransaction(transaction: MessTransaction)

    @Query("DELETE FROM mess_transactions WHERE id = :id")
    suspend fun deleteTransactionById(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMeal(meal: DailyMeal)

    @Query("DELETE FROM daily_meals WHERE dateKey = :dateKey")
    suspend fun deleteMealByDateKey(dateKey: Int)
}
