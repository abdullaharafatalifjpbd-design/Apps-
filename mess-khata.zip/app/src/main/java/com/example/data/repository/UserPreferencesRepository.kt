package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AppLanguage
import com.example.data.model.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "mess_khata_prefs")

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("app_language")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val MESS_NAME = stringPreferencesKey("mess_name")
    }

    val languageFlow: Flow<AppLanguage> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.LANGUAGE]
        enumValues<AppLanguage>().firstOrNull { it.name == raw } ?: AppLanguage.BENGALI
    }

    val themeModeFlow: Flow<AppThemeMode> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.THEME_MODE]
        enumValues<AppThemeMode>().firstOrNull { it.name == raw } ?: AppThemeMode.SYSTEM
    }

    val messNameFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.MESS_NAME] ?: ""
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LANGUAGE] = language.name
        }
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = mode.name
        }
    }

    suspend fun setMessName(name: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.MESS_NAME] = name.trim()
        }
    }
}
