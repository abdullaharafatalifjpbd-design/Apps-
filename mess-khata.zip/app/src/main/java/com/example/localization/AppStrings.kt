package com.example.localization

import com.example.data.model.AppLanguage
import com.example.data.model.AppThemeMode
import com.example.data.model.PaymentStatus
import com.example.data.model.TransactionType
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Calendar
import java.util.Locale

data class AppStrings(
    val appTitle: String,
    val developerCredit: String,
    val developerCreditDual: String,
    val defaultAccountName: String,
    // Tabs
    val tabOverview: String,
    val tabMeals: String,
    val tabLedger: String,
    val tabReport: String,
    // Header & Preferences
    val switchLangLabel: String,
    val themeLabel: String,
    val themeLight: String,
    val themeDark: String,
    val themeSystem: String,
    val settingsTitle: String,
    val accountNameLabel: String,
    val accountNameHint: String,
    val save: String,
    val cancel: String,
    val close: String,
    val delete: String,
    val edit: String,
    // Categories
    val catAll: String,
    val catDeposit: String,
    val catHouseRent: String,
    val catAuntyBill: String,
    val catUtilityBill: String,
    // Status
    val statusPaid: String,
    val statusChecked: String,
    val statusDue: String,
    // Overview
    val totalMonthlyExpenseLabel: String,
    val personalBadge: String,
    val totalGivenDeposit: String,
    val totalHouseRentLabel: String,
    val totalAuntyAndUtilityLabel: String,
    val totalMealsSummaryLabel: String,
    val quickActionsTitle: String,
    val addDepositShort: String,
    val addRentShort: String,
    val addAuntyShort: String,
    val addUtilityShort: String,
    val todayMealTitle: String,
    val breakfastLabel: String,
    val lunchLabel: String,
    val dinnerLabel: String,
    val totalMealsToday: String,
    val recentEntriesTitle: String,
    val viewAll: String,
    val noEntriesYet: String,
    val noEntriesHint: String,
    // Meals Screen
    val totalMealsMonth: String,
    val mealDaysCountLabel: String,
    val daysUnit: String,
    val addEditMealBtn: String,
    val mealLogTitle: String,
    val noMealsYet: String,
    val noMealsHint: String,
    val mealCountSuffix: String,
    // Ledger Screen
    val filteredTotalLabel: String,
    val entriesCountLabel: String,
    val addEntryBtn: String,
    // Dialogs
    val addTransactionTitle: String,
    val editTransactionTitle: String,
    val categoryLabel: String,
    val amountLabel: String,
    val amountHint: String,
    val titleLabel: String,
    val titleHint: String,
    val dateLabel: String,
    val timeLabel: String,
    val statusLabel: String,
    val noteLabel: String,
    val noteHint: String,
    val invalidAmountError: String,
    val emptyTitleError: String,
    val addMealDialogTitle: String,
    val mealNoteHint: String,
    val deleteConfirmTitle: String,
    val deleteConfirmBody: String,
    // Quick title suggestions
    val presetDeposit: String,
    val presetRent: String,
    val presetAunty: String,
    val presetUtility: String,
    // PDF Report Screen & PDF Content
    val reportScreenTitle: String,
    val reportSubtitle: String,
    val generatePdfBtn: String,
    val regeneratingPdf: String,
    val sharePdfBtn: String,
    val openPdfBtn: String,
    val savePdfBtn: String,
    val pdfPreviewTitle: String,
    val pdfSavedToast: String,
    val pdfErrorToast: String,
    val pdfHeaderTitle: String,
    val pdfGeneratedOn: String,
    val pdfSummarySection: String,
    val pdfMealSection: String,
    val pdfDepositSection: String,
    val pdfBillsSection: String,
    val pdfColDate: String,
    val pdfColDateTime: String,
    val pdfColBreakfast: String,
    val pdfColLunch: String,
    val pdfColDinner: String,
    val pdfColTotal: String,
    val pdfColNote: String,
    val pdfColDesc: String,
    val pdfColCategory: String,
    val pdfColStatus: String,
    val pdfColAmount: String,
    val pdfNoRecords: String,
    val pdfPageLabel: String,
    val pdfAccountLabel: String,
    val aboutAppDesc: String
)

object StringsProvider {
    private val bnMonths = listOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    private val enMonths = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )

    val bengali = AppStrings(
        appTitle = "Monthly Expenses",
        developerCredit = "ডিজাইন আব্দুল্লাহ",
        developerCreditDual = "ডিজাইন আব্দুল্লাহ  •  Design By Abdullah",
        defaultAccountName = "আমার ব্যক্তিগত হিসাব",
        tabOverview = "হোম",
        tabMeals = "মিল",
        tabLedger = "হিসাব",
        tabReport = "পিডিএফ",
        switchLangLabel = "EN",
        themeLabel = "থিম মোড",
        themeLight = "লাইট মোড",
        themeDark = "ডার্ক মোড",
        themeSystem = "সিস্টেম",
        settingsTitle = "সেটিংস ও অ্যাপ তথ্য",
        accountNameLabel = "আপনার নাম / হিসাবের শিরোনাম",
        accountNameHint = "যেমন: আব্দুল্লাহ - ব্যক্তিগত হিসাব",
        save = "সংরক্ষণ করুন",
        cancel = "বাতিল",
        close = "বন্ধ করুন",
        delete = "মুছুন",
        edit = "সম্পাদনা",
        catAll = "সব হিসাব",
        catDeposit = "টাকা দিয়েছি (জমা)",
        catHouseRent = "বাসা ভাড়া",
        catAuntyBill = "আন্টির বিল",
        catUtilityBill = "অন্যান্য বিল",
        statusPaid = "পরিশোধিত",
        statusChecked = "বিল দেখেছি",
        statusDue = "বাকি",
        totalMonthlyExpenseLabel = "মাসের মোট ব্যক্তিগত হিসাব",
        personalBadge = "ব্যক্তিগত",
        totalGivenDeposit = "টাকা দিয়েছি",
        totalHouseRentLabel = "বাসা ভাড়া",
        totalAuntyAndUtilityLabel = "আন্টি ও অন্যান্য বিল",
        totalMealsSummaryLabel = "মোট খাওয়া মিল",
        quickActionsTitle = "দ্রুত ব্যক্তিগত হিসাব যোগ করুন",
        addDepositShort = "টাকা দিয়েছি",
        addRentShort = "বাসা ভাড়া",
        addAuntyShort = "আন্টির বিল",
        addUtilityShort = "অন্যান্য বিল",
        todayMealTitle = "আজকের মিল হিসাব",
        breakfastLabel = "সকাল",
        lunchLabel = "দুপুর",
        dinnerLabel = "রাত",
        totalMealsToday = "আজ মোট মিল",
        recentEntriesTitle = "সাম্প্রতিক লেনদেন",
        viewAll = "সব দেখুন",
        noEntriesYet = "এই মাসে কোনো হিসাব নেই",
        noEntriesHint = "উপরের বাটন থেকে টাকা জমা, বাসা ভাড়া বা আন্টির বিল যোগ করুন",
        totalMealsMonth = "মাসের মোট মিল",
        mealDaysCountLabel = "মোট দিন",
        daysUnit = "দিন",
        addEditMealBtn = "তারিখ অনুযায়ী মিল যোগ / সম্পাদনা",
        mealLogTitle = "তারিখ অনুযায়ী মিলের তালিকা",
        noMealsYet = "এই মাসে কোনো মিল যুক্ত হয়নি",
        noMealsHint = "প্রতিদিন কয়টা মিল খাওয়া হয়েছে তা তারিখ অনুযায়ী এখানে যোগ করুন",
        mealCountSuffix = "টি মিল",
        filteredTotalLabel = "মোট পরিমাণ",
        entriesCountLabel = "টি এন্ট্রি",
        addEntryBtn = "হিসাব যোগ",
        addTransactionTitle = "নতুন ব্যক্তিগত হিসাব",
        editTransactionTitle = "হিসাব সম্পাদনা করুন",
        categoryLabel = "ধরন নির্বাচন করুন",
        amountLabel = "টাকার পরিমাণ (৳)",
        amountHint = "যেমন: ৫০০",
        titleLabel = "বিবরণ",
        titleHint = "যেমন: মাসের জমা / বাসা ভাড়া / আন্টির বিল",
        dateLabel = "তারিখ",
        timeLabel = "সময়",
        statusLabel = "অবস্থা",
        noteLabel = "নোট (ঐচ্ছিক)",
        noteHint = "বিস্তারিত লিখুন (যদি থাকে)",
        invalidAmountError = "সঠিক টাকার পরিমাণ লিখুন",
        emptyTitleError = "অনুগ্রহ করে বিবরণ লিখুন",
        addMealDialogTitle = "দৈনিক মিল হিসাব",
        mealNoteHint = "যেমন: মেহমান ১ জন / বিশেষ খাবার",
        deleteConfirmTitle = "হিসাব মুছে ফেলবেন?",
        deleteConfirmBody = "এই তথ্যটি স্থায়ীভাবে মুছে যাবে।",
        presetDeposit = "টাকা দিয়েছি (জমা)",
        presetRent = "মাসিক বাসা ভাড়া",
        presetAunty = "আন্টির বিল দেখেছি / পরিশোধ",
        presetUtility = "গ্যাস / বিদ্যুৎ / ওয়াইফাই বিল",
        reportScreenTitle = "মাসিক পিডিএফ রিপোর্ট",
        reportSubtitle = "মাসের সকল মিল, টাকা জমা, বাসা ভাড়া ও আন্টির বিলের ব্যক্তিগত হিসাব লোগোর জলছাপসহ পিডিএফ তৈরি করুন",
        generatePdfBtn = "মাসিক পিডিএফ তৈরি করুন",
        regeneratingPdf = "পিডিএফ তৈরি হচ্ছে...",
        sharePdfBtn = "শেয়ার করুন",
        openPdfBtn = "ওপেন করুন",
        savePdfBtn = "ডিভাইসে সেভ করুন",
        pdfPreviewTitle = "পিডিএফ প্রিভিউ",
        pdfSavedToast = "পিডিএফ সফলভাবে সেভ হয়েছে",
        pdfErrorToast = "পিডিএফ তৈরি করতে সমস্যা হয়েছে",
        pdfHeaderTitle = "Monthly Expenses — মাসিক ব্যক্তিগত হিসাব",
        pdfGeneratedOn = "তৈরির তারিখ",
        pdfSummarySection = "মাসিক হিসাবের সারসংক্ষেপ",
        pdfMealSection = "১. তারিখ ও বার অনুযায়ী খাবার মিল হিসাব (সকাল, দুপুর, রাত ও মোট)",
        pdfDepositSection = "২. কত তারিখে কত টাকা দিয়েছি (জমা)",
        pdfBillsSection = "৩. বাসা ভাড়া, আন্টির বিল ও অন্যান্য বিল",
        pdfColDate = "তারিখ ও বার",
        pdfColDateTime = "তারিখ ও সময়",
        pdfColBreakfast = "সকাল",
        pdfColLunch = "দুপুর",
        pdfColDinner = "রাত",
        pdfColTotal = "মোট মিল",
        pdfColNote = "নোট",
        pdfColDesc = "বিবরণ",
        pdfColCategory = "ধরন",
        pdfColStatus = "অবস্থা",
        pdfColAmount = "টাকা (৳)",
        pdfNoRecords = "এই বিভাগে কোনো তথ্য পাওয়া যায়নি।",
        pdfPageLabel = "পৃষ্ঠা",
        pdfAccountLabel = "ব্যক্তিগত হিসাব",
        aboutAppDesc = "ব্যক্তিগত মাসিক টাকা জমা, বাসা ভাড়া, আন্টির বিল, দৈনিক মিল হিসাব এবং জলছাপযুক্ত পিডিএফ তৈরির সহজ অ্যাপ।"
    )

    val english = AppStrings(
        appTitle = "Monthly Expenses",
        developerCredit = "Design By Abdullah",
        developerCreditDual = "ডিজাইন আব্দুল্লাহ  •  Design By Abdullah",
        defaultAccountName = "Personal Account",
        tabOverview = "Home",
        tabMeals = "Meals",
        tabLedger = "Ledger",
        tabReport = "PDF",
        switchLangLabel = "বাং",
        themeLabel = "Theme Mode",
        themeLight = "Light Mode",
        themeDark = "Dark Mode",
        themeSystem = "System",
        settingsTitle = "Settings & App Info",
        accountNameLabel = "Your Name / Account Title",
        accountNameHint = "e.g., Abdullah - Personal Expenses",
        save = "Save",
        cancel = "Cancel",
        close = "Close",
        delete = "Delete",
        edit = "Edit",
        catAll = "All",
        catDeposit = "Money Given",
        catHouseRent = "House Rent",
        catAuntyBill = "Aunty Bill",
        catUtilityBill = "Other Bills",
        statusPaid = "Paid",
        statusChecked = "Checked",
        statusDue = "Due",
        totalMonthlyExpenseLabel = "Total Monthly Expenses",
        personalBadge = "Personal",
        totalGivenDeposit = "Money Given",
        totalHouseRentLabel = "House Rent",
        totalAuntyAndUtilityLabel = "Aunty & Other Bills",
        totalMealsSummaryLabel = "Total Meals Eaten",
        quickActionsTitle = "Quick Add Personal Entry",
        addDepositShort = "Money Given",
        addRentShort = "House Rent",
        addAuntyShort = "Aunty Bill",
        addUtilityShort = "Other Bills",
        todayMealTitle = "Today's Meal Tracker",
        breakfastLabel = "Morning",
        lunchLabel = "Lunch",
        dinnerLabel = "Dinner",
        totalMealsToday = "Today Total",
        recentEntriesTitle = "Recent Transactions",
        viewAll = "View All",
        noEntriesYet = "No entries for this month",
        noEntriesHint = "Tap above to log money given, house rent, aunty bill, or other bills",
        totalMealsMonth = "Monthly Total Meals",
        mealDaysCountLabel = "Tracked Days",
        daysUnit = "days",
        addEditMealBtn = "Add / Edit Meal by Date",
        mealLogTitle = "Date-by-Date Meal Log",
        noMealsYet = "No meals recorded this month",
        noMealsHint = "Record how many meals you ate each day to track your monthly count",
        mealCountSuffix = "meals",
        filteredTotalLabel = "Total",
        entriesCountLabel = "entries",
        addEntryBtn = "Add Entry",
        addTransactionTitle = "Add Personal Entry",
        editTransactionTitle = "Edit Entry",
        categoryLabel = "Select Category",
        amountLabel = "Amount (৳)",
        amountHint = "e.g., 500",
        titleLabel = "Description",
        titleHint = "e.g., Money Given / House Rent / Aunty Bill",
        dateLabel = "Date",
        timeLabel = "Time",
        statusLabel = "Status",
        noteLabel = "Note (Optional)",
        noteHint = "Add extra details if needed",
        invalidAmountError = "Please enter a valid amount",
        emptyTitleError = "Please enter a description",
        addMealDialogTitle = "Daily Meal Entry",
        mealNoteHint = "e.g., +1 Guest / Special meal",
        deleteConfirmTitle = "Delete Entry?",
        deleteConfirmBody = "This record will be permanently removed.",
        presetDeposit = "Money Given",
        presetRent = "Monthly House Rent",
        presetAunty = "Aunty Bill Checked / Paid",
        presetUtility = "Gas / Electricity / WiFi Bill",
        reportScreenTitle = "Monthly PDF Report",
        reportSubtitle = "Generate a watermarked monthly PDF statement of your personal meals, money given, house rent, and aunty bills",
        generatePdfBtn = "Generate Monthly PDF",
        regeneratingPdf = "Generating PDF...",
        sharePdfBtn = "Share",
        openPdfBtn = "Open",
        savePdfBtn = "Save PDF",
        pdfPreviewTitle = "PDF Preview",
        pdfSavedToast = "PDF saved successfully",
        pdfErrorToast = "Failed to generate PDF",
        pdfHeaderTitle = "Monthly Expenses — Personal Statement",
        pdfGeneratedOn = "Generated On",
        pdfSummarySection = "Monthly Personal Summary",
        pdfMealSection = "1. Meal Record by Date & Day (Morning, Lunch, Dinner & Total)",
        pdfDepositSection = "2. Money Given Record (By Date)",
        pdfBillsSection = "3. House Rent, Aunty Bill & Other Bills",
        pdfColDate = "Date & Day",
        pdfColDateTime = "Date & Time",
        pdfColBreakfast = "Morning",
        pdfColLunch = "Lunch",
        pdfColDinner = "Dinner",
        pdfColTotal = "Total",
        pdfColNote = "Note",
        pdfColDesc = "Description",
        pdfColCategory = "Category",
        pdfColStatus = "Status",
        pdfColAmount = "Amount (৳)",
        pdfNoRecords = "No records found in this section.",
        pdfPageLabel = "Page",
        pdfAccountLabel = "Personal Account",
        aboutAppDesc = "Personal tracker for money given, house rent, aunty bills, daily meals, and watermarked monthly PDF reports."
    )

    fun get(language: AppLanguage): AppStrings =
        if (language == AppLanguage.BENGALI) bengali else english

    fun categoryName(type: TransactionType, strings: AppStrings): String = when (type) {
        TransactionType.DEPOSIT -> strings.catDeposit
        TransactionType.HOUSE_RENT -> strings.catHouseRent
        TransactionType.AUNTY_BILL -> strings.catAuntyBill
        TransactionType.UTILITY_BILL -> strings.catUtilityBill
    }

    fun statusName(status: PaymentStatus, strings: AppStrings): String = when (status) {
        PaymentStatus.PAID -> strings.statusPaid
        PaymentStatus.CHECKED -> strings.statusChecked
        PaymentStatus.DUE -> strings.statusDue
    }

    fun presetTitle(type: TransactionType, strings: AppStrings): String = when (type) {
        TransactionType.DEPOSIT -> strings.presetDeposit
        TransactionType.HOUSE_RENT -> strings.presetRent
        TransactionType.AUNTY_BILL -> strings.presetAunty
        TransactionType.UTILITY_BILL -> strings.presetUtility
    }

    fun themeLabel(mode: AppThemeMode, strings: AppStrings): String = when (mode) {
        AppThemeMode.LIGHT -> strings.themeLight
        AppThemeMode.DARK -> strings.themeDark
        AppThemeMode.SYSTEM -> strings.themeSystem
    }

    fun toLocalizedDigits(input: String, language: AppLanguage): String {
        if (language == AppLanguage.ENGLISH) return input
        val bnDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        val sb = StringBuilder(input.length)
        for (ch in input) {
            if (ch in '0'..'9') {
                sb.append(bnDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun formatCurrency(amount: Double, language: AppLanguage): String {
        val formatter = DecimalFormat("#,##0.##", DecimalFormatSymbols(Locale.US))
        val formatted = "৳" + formatter.format(kotlin.math.abs(amount))
        val signed = if (amount < 0) "-$formatted" else formatted
        return toLocalizedDigits(signed, language)
    }

    fun formatMealCount(count: Double, language: AppLanguage): String {
        val formatter = DecimalFormat("0.##", DecimalFormatSymbols(Locale.US))
        return toLocalizedDigits(formatter.format(count), language)
    }

    fun formatMonthYear(year: Int, month: Int, language: AppLanguage): String {
        val idx = (month - 1).coerceIn(0, 11)
        val monthName = if (language == AppLanguage.BENGALI) bnMonths[idx] else enMonths[idx]
        val yearStr = toLocalizedDigits(year.toString(), language)
        return "$monthName $yearStr"
    }

    fun formatDate(year: Int, month: Int, day: Int, language: AppLanguage): String {
        val idx = (month - 1).coerceIn(0, 11)
        val monthShort = if (language == AppLanguage.BENGALI) bnMonths[idx] else enMonths[idx].take(3)
        val dayStr = toLocalizedDigits(day.toString().padStart(2, '0'), language)
        val yearStr = toLocalizedDigits(year.toString(), language)
        return "$dayStr $monthShort $yearStr"
    }

    fun formatShortDate(year: Int, month: Int, day: Int, language: AppLanguage): String {
        val idx = (month - 1).coerceIn(0, 11)
        val monthShort = if (language == AppLanguage.BENGALI) bnMonths[idx] else enMonths[idx].take(3)
        val dayStr = toLocalizedDigits(day.toString().padStart(2, '0'), language)
        return "$dayStr $monthShort"
    }

    fun formatDateWithDay(year: Int, month: Int, day: Int, language: AppLanguage): String {
        val cal = Calendar.getInstance().apply {
            clear()
            set(year, month - 1, day)
        }
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val dayName = if (language == AppLanguage.BENGALI) {
            when (dayOfWeek) {
                Calendar.SATURDAY -> "শনিবার"
                Calendar.SUNDAY -> "রবিবার"
                Calendar.MONDAY -> "সোমবার"
                Calendar.TUESDAY -> "মঙ্গলবার"
                Calendar.WEDNESDAY -> "বুধবার"
                Calendar.THURSDAY -> "বৃহস্পতিবার"
                Calendar.FRIDAY -> "শুক্রবার"
                else -> ""
            }
        } else {
            when (dayOfWeek) {
                Calendar.SATURDAY -> "Sat"
                Calendar.SUNDAY -> "Sun"
                Calendar.MONDAY -> "Mon"
                Calendar.TUESDAY -> "Tue"
                Calendar.WEDNESDAY -> "Wed"
                Calendar.THURSDAY -> "Thu"
                Calendar.FRIDAY -> "Fri"
                else -> ""
            }
        }
        return "${formatShortDate(year, month, day, language)} ($dayName)"
    }

    fun formatTime(timestampMillis: Long, language: AppLanguage): String {
        val cal = Calendar.getInstance().apply { timeInMillis = timestampMillis }
        val hour24 = cal.get(Calendar.HOUR_OF_DAY)
        val minute = cal.get(Calendar.MINUTE)
        val isPm = hour24 >= 12
        val hour12 = when {
            hour24 == 0 -> 12
            hour24 > 12 -> hour24 - 12
            else -> hour24
        }
        val minStr = minute.toString().padStart(2, '0')
        val period = if (language == AppLanguage.BENGALI) {
            when {
                hour24 < 6 -> "ভোর"
                hour24 < 12 -> "সকাল"
                hour24 < 16 -> "দুপুর"
                hour24 < 19 -> "বিকাল"
                else -> "রাত"
            }
        } else {
            if (isPm) "PM" else "AM"
        }
        val timeDigits = toLocalizedDigits("${hour12}:$minStr", language)
        return if (language == AppLanguage.BENGALI) "$period $timeDigits" else "$timeDigits $period"
    }
}
