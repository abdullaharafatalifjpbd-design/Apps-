package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Restaurant
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.local.AppDatabase
import com.example.data.model.AppThemeMode
import com.example.data.model.DailyMeal
import com.example.data.model.MessTransaction
import com.example.data.model.TransactionType
import com.example.data.repository.MessRepository
import com.example.data.repository.UserPreferencesRepository
import com.example.localization.StringsProvider
import com.example.ui.MessViewModel
import com.example.ui.components.BrandTopBar
import com.example.ui.components.MealEditorDialog
import com.example.ui.components.MonthSelectorBar
import com.example.ui.components.SettingsAboutDialog
import com.example.ui.components.TransactionEditorDialog
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.LedgerScreen
import com.example.ui.screens.MealsScreen
import com.example.ui.screens.PdfReportScreen
import com.example.ui.theme.MessKhataTheme

enum class AppTab(
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
) {
    HOME(Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
    MEALS(Icons.Filled.Restaurant, Icons.Outlined.Restaurant, "nav_meals"),
    LEDGER(Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong, "nav_ledger"),
    PDF(Icons.Filled.PictureAsPdf, Icons.Outlined.PictureAsPdf, "nav_pdf")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MessViewModel = viewModel(
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[APPLICATION_KEY])
                        val db = AppDatabase.getInstance(app)
                        val repo = MessRepository(db.messDao())
                        val prefs = UserPreferencesRepository(app)
                        MessViewModel(repo, prefs)
                    }
                }
            )
            MessKhataApp(viewModel = viewModel)
        }
    }
}

@Composable
fun MessKhataApp(viewModel: MessViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val systemDark = isSystemInDarkTheme()
    val isDark = when (state.themeMode) {
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
        AppThemeMode.SYSTEM -> systemDark
    }
    val strings = StringsProvider.get(state.language)

    var selectedTab by remember { mutableStateOf(AppTab.HOME) }
    var txDialogVisible by remember { mutableStateOf(false) }
    var editingTx by remember { mutableStateOf<MessTransaction?>(null) }
    var initialTxType by remember { mutableStateOf(TransactionType.DEPOSIT) }

    var mealDialogVisible by remember { mutableStateOf(false) }
    var editingMeal by remember { mutableStateOf<DailyMeal?>(null) }

    var settingsDialogVisible by remember { mutableStateOf(false) }
    var pendingDeleteTx by remember { mutableStateOf<MessTransaction?>(null) }
    var pendingDeleteMeal by remember { mutableStateOf<DailyMeal?>(null) }

    val context = LocalContext.current

    BackHandler(enabled = selectedTab != AppTab.HOME) {
        selectedTab = AppTab.HOME
    }

    MessKhataTheme(darkTheme = isDark) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 700.dp

            Scaffold(
                contentWindowInsets = WindowInsets.safeDrawing,
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    if (!useRail) {
                        NavigationBar {
                            AppTab.entries.forEach { tab ->
                                val label = when (tab) {
                                    AppTab.HOME -> strings.tabOverview
                                    AppTab.MEALS -> strings.tabMeals
                                    AppTab.LEDGER -> strings.tabLedger
                                    AppTab.PDF -> strings.tabReport
                                }
                                val isSelected = selectedTab == tab
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { selectedTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = label
                                        )
                                    },
                                    label = { Text(label) },
                                    modifier = Modifier.testTag(tab.tag)
                                )
                            }
                        }
                    }
                },
                floatingActionButton = {
                    if (selectedTab != AppTab.PDF) {
                        ExtendedFloatingActionButton(
                            onClick = {
                                if (selectedTab == AppTab.MEALS) {
                                    editingMeal = state.todayMeal
                                    mealDialogVisible = true
                                } else {
                                    editingTx = null
                                    initialTxType = state.categoryFilter ?: TransactionType.DEPOSIT
                                    txDialogVisible = true
                                }
                            },
                            icon = { Icon(Icons.Outlined.Add, contentDescription = null) },
                            text = {
                                Text(
                                    if (selectedTab == AppTab.MEALS) strings.tabMeals else strings.addEntryBtn
                                )
                            },
                            modifier = Modifier.testTag("main_fab")
                        )
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail) {
                        NavigationRail(
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            AppTab.entries.forEach { tab ->
                                val label = when (tab) {
                                    AppTab.HOME -> strings.tabOverview
                                    AppTab.MEALS -> strings.tabMeals
                                    AppTab.LEDGER -> strings.tabLedger
                                    AppTab.PDF -> strings.tabReport
                                }
                                val isSelected = selectedTab == tab
                                NavigationRailItem(
                                    selected = isSelected,
                                    onClick = { selectedTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = label
                                        )
                                    },
                                    label = { Text(label) },
                                    modifier = Modifier.testTag(tab.tag)
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 760.dp)
                        ) {
                            BrandTopBar(
                                strings = strings,
                                isDark = isDark,
                                onToggleLanguage = { viewModel.toggleLanguage() },
                                onToggleTheme = { viewModel.toggleTheme(isDark) },
                                onOpenSettings = { settingsDialogVisible = true }
                            )

                            MonthSelectorBar(
                                year = state.selectedYear,
                                month = state.selectedMonth,
                                language = state.language,
                                onPreviousMonth = { viewModel.previousMonth() },
                                onNextMonth = { viewModel.nextMonth() }
                            )

                            when (selectedTab) {
                                AppTab.HOME -> DashboardScreen(
                                    state = state,
                                    strings = strings,
                                    onQuickAddTransaction = { type ->
                                        editingTx = null
                                        initialTxType = type
                                        txDialogVisible = true
                                    },
                                    onAdjustTodayMeal = { slot, delta ->
                                        viewModel.adjustTodayMeal(slot, delta)
                                    },
                                    onOpenMealDialog = {
                                        editingMeal = state.todayMeal
                                        mealDialogVisible = true
                                    },
                                    onEditTransaction = { tx ->
                                        editingTx = tx
                                        initialTxType = tx.type
                                        txDialogVisible = true
                                    },
                                    onDeleteTransaction = { tx -> pendingDeleteTx = tx },
                                    onViewAllLedger = {
                                        viewModel.setCategoryFilter(null)
                                        selectedTab = AppTab.LEDGER
                                    },
                                    onOpenSettings = { settingsDialogVisible = true },
                                    modifier = Modifier.weight(1f)
                                )

                                AppTab.MEALS -> MealsScreen(
                                    state = state,
                                    strings = strings,
                                    onAddMeal = {
                                        editingMeal = null
                                        mealDialogVisible = true
                                    },
                                    onEditMeal = { meal ->
                                        editingMeal = meal
                                        mealDialogVisible = true
                                    },
                                    onDeleteMeal = { meal -> pendingDeleteMeal = meal },
                                    modifier = Modifier.weight(1f)
                                )

                                AppTab.LEDGER -> LedgerScreen(
                                    state = state,
                                    strings = strings,
                                    onSelectFilter = { viewModel.setCategoryFilter(it) },
                                    onEditTransaction = { tx ->
                                        editingTx = tx
                                        initialTxType = tx.type
                                        txDialogVisible = true
                                    },
                                    onDeleteTransaction = { tx -> pendingDeleteTx = tx },
                                    modifier = Modifier.weight(1f)
                                )

                                AppTab.PDF -> PdfReportScreen(
                                    state = state,
                                    strings = strings,
                                    onUpdateMessName = { viewModel.updateMessName(it) },
                                    onGeneratePdf = { viewModel.generateMonthlyPdf(context) },
                                    onOpenSettings = { settingsDialogVisible = true },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }

        if (txDialogVisible) {
            TransactionEditorDialog(
                initialTransaction = editingTx,
                initialType = initialTxType,
                defaultYear = state.selectedYear,
                defaultMonth = state.selectedMonth,
                strings = strings,
                language = state.language,
                onDismiss = { txDialogVisible = false },
                onSave = { id, type, amount, year, month, day, ts, title, note, status ->
                    viewModel.saveTransaction(id, type, amount, year, month, day, ts, title, note, status)
                    txDialogVisible = false
                }
            )
        }

        if (mealDialogVisible) {
            MealEditorDialog(
                initialMeal = editingMeal,
                defaultYear = state.selectedYear,
                defaultMonth = state.selectedMonth,
                strings = strings,
                language = state.language,
                onDismiss = { mealDialogVisible = false },
                onSave = { year, month, day, breakfast, lunch, dinner, note ->
                    viewModel.saveMeal(year, month, day, breakfast, lunch, dinner, note)
                    mealDialogVisible = false
                }
            )
        }

        if (settingsDialogVisible) {
            SettingsAboutDialog(
                messName = state.messName,
                language = state.language,
                themeMode = state.themeMode,
                strings = strings,
                onUpdateMessName = { viewModel.updateMessName(it) },
                onSelectLanguage = { viewModel.setLanguage(it) },
                onSelectTheme = { viewModel.setThemeMode(it) },
                onDismiss = { settingsDialogVisible = false }
            )
        }

        pendingDeleteTx?.let { tx ->
            AlertDialog(
                onDismissRequest = { pendingDeleteTx = null },
                title = { Text(strings.deleteConfirmTitle) },
                text = { Text("${tx.title} — ${strings.deleteConfirmBody}") },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.deleteTransaction(tx.id)
                            pendingDeleteTx = null
                        },
                        modifier = Modifier.testTag("confirm_delete_tx")
                    ) {
                        Text(strings.delete, color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDeleteTx = null }) {
                        Text(strings.cancel)
                    }
                }
            )
        }

        pendingDeleteMeal?.let { meal ->
            AlertDialog(
                onDismissRequest = { pendingDeleteMeal = null },
                title = { Text(strings.deleteConfirmTitle) },
                text = {
                    Text(
                        "${StringsProvider.formatDate(meal.year, meal.month, meal.day, state.language)} — ${strings.deleteConfirmBody}"
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.deleteMeal(meal.dateKey)
                            pendingDeleteMeal = null
                        },
                        modifier = Modifier.testTag("confirm_delete_meal")
                    ) {
                        Text(strings.delete, color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDeleteMeal = null }) {
                        Text(strings.cancel)
                    }
                }
            )
        }
    }
}
