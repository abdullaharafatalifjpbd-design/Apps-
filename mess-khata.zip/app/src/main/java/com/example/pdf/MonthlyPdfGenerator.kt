package com.example.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.DailyMeal
import com.example.data.model.MessTransaction
import com.example.data.model.MonthSummary
import com.example.data.model.TransactionType
import com.example.localization.AppStrings
import com.example.localization.StringsProvider
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar

data class GeneratedPdfResult(
    val file: File,
    val pageCount: Int,
    val previewPages: List<Bitmap>
)

object MonthlyPdfGenerator {
    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 32f
    private const val CONTENT_WIDTH = PAGE_WIDTH - (MARGIN * 2)
    private const val FOOTER_Y = PAGE_HEIGHT - 30f
    private const val MAX_Y = PAGE_HEIGHT - 54f

    fun generate(
        context: Context,
        language: AppLanguage,
        accountName: String,
        summary: MonthSummary,
        transactions: List<MessTransaction>,
        meals: List<DailyMeal>
    ): GeneratedPdfResult {
        val strings = StringsProvider.get(language)
        val typeface = ResourcesCompat.getFont(context, R.font.hind_siliguri) ?: Typeface.DEFAULT
        val logoBmp = runCatching {
            BitmapFactory.decodeResource(context.resources, R.drawable.brand_logo)
        }.getOrNull()

        val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val fileName = "MonthlyExpenses_${summary.year}_${summary.month.toString().padStart(2, '0')}.pdf"
        val outFile = File(reportsDir, fileName)

        val pdf = PdfDocument()
        try {
            val writer = PdfPageWriter(
                pdf = pdf,
                typeface = typeface,
                logoBitmap = logoBmp,
                strings = strings,
                language = language
            )

            writer.startNewPage()
            writer.drawHeader(
                accountName = accountName.ifBlank { strings.defaultAccountName },
                summary = summary
            )
            writer.drawSummarySection(summary)

            // 1. Daily Meals Table (Date & Day, Morning, Lunch, Dinner, Total, Note)
            val sortedMeals = meals.sortedBy { it.day }
            writer.drawSectionTitle(strings.pdfMealSection, Color.parseColor("#B45309"))
            if (sortedMeals.isEmpty()) {
                writer.drawEmptyMessage(strings.pdfNoRecords)
            } else {
                val cols = floatArrayOf(0.25f, 0.12f, 0.12f, 0.12f, 0.14f, 0.25f)
                val headers = listOf(
                    strings.pdfColDate,
                    strings.pdfColBreakfast,
                    strings.pdfColLunch,
                    strings.pdfColDinner,
                    strings.pdfColTotal,
                    strings.pdfColNote
                )
                writer.drawTableHeader(headers, cols)
                sortedMeals.forEachIndexed { idx, meal ->
                    writer.drawTableRow(
                        cells = listOf(
                            StringsProvider.formatDateWithDay(meal.year, meal.month, meal.day, language),
                            StringsProvider.formatMealCount(meal.breakfast, language),
                            StringsProvider.formatMealCount(meal.lunch, language),
                            StringsProvider.formatMealCount(meal.dinner, language),
                            StringsProvider.formatMealCount(meal.totalMeals, language),
                            meal.note.ifBlank { "-" }
                        ),
                        ratios = cols,
                        shaded = idx % 2 == 1,
                        repeatHeader = headers
                    )
                }
                val totalBreakfast = sortedMeals.sumOf { it.breakfast }
                val totalLunch = sortedMeals.sumOf { it.lunch }
                val totalDinner = sortedMeals.sumOf { it.dinner }
                val grandTotalMeals = sortedMeals.sumOf { it.totalMeals }
                writer.drawTableRow(
                    cells = listOf(
                        if (language == AppLanguage.BENGALI) "সর্বমোট (${StringsProvider.toLocalizedDigits(sortedMeals.size.toString(), language)} দিন)" else "Total (${sortedMeals.size} days)",
                        StringsProvider.formatMealCount(totalBreakfast, language),
                        StringsProvider.formatMealCount(totalLunch, language),
                        StringsProvider.formatMealCount(totalDinner, language),
                        StringsProvider.formatMealCount(grandTotalMeals, language),
                        "-"
                    ),
                    ratios = cols,
                    shaded = true,
                    bold = true,
                    repeatHeader = headers
                )
            }
            writer.addSpace(14f)

            // 2. Money Given / Deposits Table
            val deposits = transactions.filter { it.type == TransactionType.DEPOSIT }.sortedBy { it.day }
            writer.drawSectionTitle(strings.pdfDepositSection, Color.parseColor("#0369A1"))
            if (deposits.isEmpty()) {
                writer.drawEmptyMessage(strings.pdfNoRecords)
            } else {
                val cols = floatArrayOf(0.28f, 0.30f, 0.24f, 0.18f)
                val headers = listOf(
                    strings.pdfColDateTime,
                    strings.pdfColDesc,
                    strings.pdfColNote,
                    strings.pdfColAmount
                )
                writer.drawTableHeader(headers, cols)
                deposits.forEachIndexed { idx, tx ->
                    writer.drawTableRow(
                        cells = listOf(
                            "${StringsProvider.formatDateWithDay(tx.year, tx.month, tx.day, language)} • ${StringsProvider.formatTime(tx.timestampMillis, language)}",
                            tx.title,
                            tx.note.ifBlank { "-" },
                            StringsProvider.formatCurrency(tx.amount, language)
                        ),
                        ratios = cols,
                        shaded = idx % 2 == 1,
                        repeatHeader = headers
                    )
                }
            }
            writer.addSpace(14f)

            // 3. House Rent, Aunty Bill & Other Bills
            val bills = transactions.filter {
                it.type == TransactionType.HOUSE_RENT ||
                    it.type == TransactionType.AUNTY_BILL ||
                    it.type == TransactionType.UTILITY_BILL
            }.sortedBy { it.day }
            writer.drawSectionTitle(strings.pdfBillsSection, Color.parseColor("#047857"))
            if (bills.isEmpty()) {
                writer.drawEmptyMessage(strings.pdfNoRecords)
            } else {
                val cols = floatArrayOf(0.25f, 0.20f, 0.15f, 0.24f, 0.16f)
                val headers = listOf(
                    strings.pdfColDateTime,
                    strings.pdfColCategory,
                    strings.pdfColStatus,
                    strings.pdfColDesc,
                    strings.pdfColAmount
                )
                writer.drawTableHeader(headers, cols)
                bills.forEachIndexed { idx, tx ->
                    writer.drawTableRow(
                        cells = listOf(
                            "${StringsProvider.formatDateWithDay(tx.year, tx.month, tx.day, language)} • ${StringsProvider.formatTime(tx.timestampMillis, language)}",
                            StringsProvider.categoryName(tx.type, strings),
                            StringsProvider.statusName(tx.status, strings),
                            tx.title + if (tx.note.isNotBlank()) " (${tx.note})" else "",
                            StringsProvider.formatCurrency(tx.amount, language)
                        ),
                        ratios = cols,
                        shaded = idx % 2 == 1,
                        repeatHeader = headers
                    )
                }
            }

            val pageCount = writer.finishCurrentPage()
            FileOutputStream(outFile).use { fos ->
                pdf.writeTo(fos)
            }
            val previewPages = renderPdfPages(outFile)
            return GeneratedPdfResult(
                file = outFile,
                pageCount = pageCount,
                previewPages = previewPages
            )
        } finally {
            pdf.close()
            logoBmp?.recycle()
        }
    }

    private fun renderPdfPages(file: File): List<Bitmap> {
        val bitmaps = mutableListOf<Bitmap>()
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                for (i in 0 until renderer.pageCount) {
                    renderer.openPage(i).use { page ->
                        val scale = 2
                        val bmp = Bitmap.createBitmap(
                            page.width * scale,
                            page.height * scale,
                            Bitmap.Config.ARGB_8888
                        )
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bitmaps.add(bmp)
                    }
                }
            }
        }
        return bitmaps
    }

    private class PdfPageWriter(
        private val pdf: PdfDocument,
        private val typeface: Typeface,
        private val logoBitmap: Bitmap?,
        private val strings: AppStrings,
        private val language: AppLanguage
    ) {
        private var currentPage: PdfDocument.Page? = null
        private var canvas: Canvas? = null
        private var y = MARGIN
        private var pageNumber = 0

        private val bgPaint = Paint().apply { style = Paint.Style.FILL }
        private val strokePaint = Paint().apply {
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
            color = Color.parseColor("#CBD5E1")
        }
        private val watermarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            alpha = 24 // ~9.5% opacity subtle logo watermark on every page
            isFilterBitmap = true
        }

        private fun makeTextPaint(
            sizeSp: Float,
            color: Int,
            bold: Boolean = false
        ): TextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = sizeSp
            this.color = color
            this.typeface = if (bold) Typeface.create(typeface, Typeface.BOLD) else typeface
        }

        fun startNewPage() {
            currentPage?.let {
                drawFooter()
                pdf.finishPage(it)
            }
            pageNumber++
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            currentPage = pdf.startPage(pageInfo)
            canvas = currentPage!!.canvas
            canvas!!.drawColor(Color.WHITE)
            drawWatermark()
            y = MARGIN
        }

        private fun drawWatermark() {
            val c = canvas ?: return
            val bmp = logoBitmap ?: return
            val wmSize = 290f
            val left = (PAGE_WIDTH - wmSize) / 2f
            val top = (PAGE_HEIGHT - wmSize) / 2f
            val destRect = RectF(left, top, left + wmSize, top + wmSize)
            c.drawBitmap(bmp, null, destRect, watermarkPaint)
        }

        fun finishCurrentPage(): Int {
            currentPage?.let {
                drawFooter()
                pdf.finishPage(it)
            }
            currentPage = null
            return pageNumber
        }

        fun addSpace(height: Float) {
            y += height
        }

        private fun ensureSpace(neededHeight: Float) {
            if (y + neededHeight > MAX_Y) {
                startNewPage()
            }
        }

        private fun drawStaticText(
            text: String,
            x: Float,
            topY: Float,
            width: Float,
            paint: TextPaint,
            align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL
        ): Float {
            val c = canvas ?: return 0f
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width.toInt().coerceAtLeast(10))
                .setAlignment(align)
                .setLineSpacing(1.5f, 1.05f)
                .setIncludePad(false)
                .build()
            c.save()
            c.translate(x, topY)
            layout.draw(c)
            c.restore()
            return layout.height.toFloat()
        }

        fun drawHeader(accountName: String, summary: MonthSummary) {
            val c = canvas ?: return
            val bannerHeight = 84f
            val rect = RectF(MARGIN, y, MARGIN + CONTENT_WIDTH, y + bannerHeight)
            bgPaint.color = Color.parseColor("#011636")
            c.drawRoundRect(rect, 12f, 12f, bgPaint)

            val textStartX = if (logoBitmap != null) {
                val destRect = RectF(MARGIN + 12f, y + 12f, MARGIN + 72f, y + 72f)
                c.drawBitmap(logoBitmap, null, destRect, null)
                MARGIN + 84f
            } else {
                MARGIN + 16f
            }

            val titlePaint = makeTextPaint(15f, Color.WHITE, bold = true)
            val subPaint = makeTextPaint(10.5f, Color.parseColor("#93C5FD"))
            val metaPaint = makeTextPaint(9.5f, Color.parseColor("#E2E8F0"))

            drawStaticText(strings.pdfHeaderTitle, textStartX, y + 12f, CONTENT_WIDTH - 96f, titlePaint)
            val monthText = StringsProvider.formatMonthYear(summary.year, summary.month, language)
            drawStaticText(
                "${strings.pdfAccountLabel}: $accountName  |  $monthText",
                textStartX,
                y + 36f,
                CONTENT_WIDTH - 96f,
                subPaint
            )
            val nowCal = Calendar.getInstance()
            val genDate = StringsProvider.formatDate(
                nowCal.get(Calendar.YEAR),
                nowCal.get(Calendar.MONTH) + 1,
                nowCal.get(Calendar.DAY_OF_MONTH),
                language
            )
            drawStaticText(
                "${strings.pdfGeneratedOn}: $genDate  •  ${strings.developerCredit}",
                textStartX,
                y + 56f,
                CONTENT_WIDTH - 96f,
                metaPaint
            )

            y += bannerHeight + 14f
        }

        fun drawSummarySection(summary: MonthSummary) {
            val c = canvas ?: return
            drawSectionTitle(strings.pdfSummarySection, Color.parseColor("#0066E6"))

            val items = listOf(
                strings.totalMonthlyExpenseLabel to StringsProvider.formatCurrency(summary.totalMonthlyExpense, language),
                strings.totalGivenDeposit to StringsProvider.formatCurrency(summary.totalDeposit, language),
                strings.catHouseRent to StringsProvider.formatCurrency(summary.totalHouseRent, language),
                strings.catAuntyBill to StringsProvider.formatCurrency(summary.totalAuntyBill, language),
                strings.catUtilityBill to StringsProvider.formatCurrency(summary.totalUtilityBill, language),
                strings.totalMealsMonth to "${StringsProvider.formatMealCount(summary.totalMeals, language)} ${strings.mealCountSuffix} (${StringsProvider.toLocalizedDigits(summary.mealDaysCount.toString(), language)} ${strings.daysUnit})"
            )

            val boxWidth = (CONTENT_WIDTH - 10f) / 2f
            val rowHeight = 32f
            val labelPaint = makeTextPaint(8.8f, Color.parseColor("#475569"))
            val valPaint = makeTextPaint(10.5f, Color.parseColor("#0F172A"), bold = true)

            for (i in items.indices step 2) {
                ensureSpace(rowHeight + 6f)
                for (col in 0..1) {
                    val idx = i + col
                    if (idx < items.size) {
                        val left = MARGIN + col * (boxWidth + 10f)
                        val rect = RectF(left, y, left + boxWidth, y + rowHeight)
                        bgPaint.color = Color.argb(215, 248, 250, 252)
                        c.drawRoundRect(rect, 6f, 6f, bgPaint)
                        c.drawRoundRect(rect, 6f, 6f, strokePaint)
                        drawStaticText(items[idx].first, left + 8f, y + 4f, boxWidth - 16f, labelPaint)
                        drawStaticText(items[idx].second, left + 8f, y + 16f, boxWidth - 16f, valPaint)
                    }
                }
                y += rowHeight + 6f
            }
            y += 8f
        }

        fun drawSectionTitle(title: String, accentColor: Int) {
            ensureSpace(26f)
            val c = canvas ?: return
            bgPaint.color = accentColor
            c.drawRoundRect(RectF(MARGIN, y + 2f, MARGIN + 4f, y + 18f), 2f, 2f, bgPaint)
            val titlePaint = makeTextPaint(11.5f, Color.parseColor("#0F172A"), bold = true)
            val h = drawStaticText(title, MARGIN + 10f, y, CONTENT_WIDTH - 10f, titlePaint)
            y += h.coerceAtLeast(18f) + 6f
        }

        fun drawEmptyMessage(msg: String) {
            ensureSpace(22f)
            val paint = makeTextPaint(9.5f, Color.parseColor("#64748B"))
            val h = drawStaticText(msg, MARGIN + 8f, y, CONTENT_WIDTH - 16f, paint)
            y += h + 8f
        }

        fun drawTableHeader(headers: List<String>, ratios: FloatArray) {
            ensureSpace(24f)
            val c = canvas ?: return
            val headerPaint = makeTextPaint(9f, Color.WHITE, bold = true)
            val rowHeight = 22f
            bgPaint.color = Color.parseColor("#1E293B")
            c.drawRect(MARGIN, y, MARGIN + CONTENT_WIDTH, y + rowHeight, bgPaint)

            var x = MARGIN
            headers.forEachIndexed { idx, text ->
                val colW = CONTENT_WIDTH * ratios[idx]
                drawStaticText(text, x + 5f, y + 5f, colW - 10f, headerPaint)
                x += colW
            }
            y += rowHeight
        }

        fun drawTableRow(
            cells: List<String>,
            ratios: FloatArray,
            shaded: Boolean,
            bold: Boolean = false,
            repeatHeader: List<String>
        ) {
            val cellPaint = makeTextPaint(8.8f, Color.parseColor("#1E293B"), bold = bold)
            var maxH = 16f
            cells.forEachIndexed { idx, text ->
                val colW = (CONTENT_WIDTH * ratios[idx] - 10f).toInt().coerceAtLeast(10)
                val layout = StaticLayout.Builder.obtain(text, 0, text.length, cellPaint, colW)
                    .setLineSpacing(1.2f, 1.0f)
                    .setIncludePad(false)
                    .build()
                if (layout.height + 10f > maxH) {
                    maxH = layout.height + 10f
                }
            }

            if (y + maxH > MAX_Y) {
                startNewPage()
                drawTableHeader(repeatHeader, ratios)
            }

            val c = canvas ?: return
            bgPaint.color = if (shaded) Color.argb(190, 241, 245, 249) else Color.argb(180, 255, 255, 255)
            c.drawRect(MARGIN, y, MARGIN + CONTENT_WIDTH, y + maxH, bgPaint)
            c.drawLine(MARGIN, y + maxH, MARGIN + CONTENT_WIDTH, y + maxH, strokePaint)

            var x = MARGIN
            cells.forEachIndexed { idx, text ->
                val colW = CONTENT_WIDTH * ratios[idx]
                drawStaticText(text, x + 5f, y + 5f, colW - 10f, cellPaint)
                x += colW
            }
            y += maxH
        }

        private fun drawFooter() {
            val c = canvas ?: return
            c.drawLine(MARGIN, FOOTER_Y - 8f, MARGIN + CONTENT_WIDTH, FOOTER_Y - 8f, strokePaint)
            val footerPaint = makeTextPaint(8.8f, Color.parseColor("#475569"), bold = true)
            val pagePaint = makeTextPaint(8.8f, Color.parseColor("#64748B"))
            drawStaticText(
                strings.developerCreditDual,
                MARGIN,
                FOOTER_Y,
                CONTENT_WIDTH * 0.75f,
                footerPaint
            )
            val pageNumStr = StringsProvider.toLocalizedDigits(pageNumber.toString(), language)
            drawStaticText(
                "${strings.pdfPageLabel} $pageNumStr",
                MARGIN + CONTENT_WIDTH * 0.75f,
                FOOTER_Y,
                CONTENT_WIDTH * 0.25f,
                pagePaint,
                align = Layout.Alignment.ALIGN_OPPOSITE
            )
        }
    }
}
