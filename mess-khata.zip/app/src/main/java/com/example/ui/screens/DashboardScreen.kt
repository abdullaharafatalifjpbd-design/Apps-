package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material.icons.outlined.RestaurantMenu
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.DailyMeal
import com.example.data.model.MessTransaction
import com.example.data.model.TransactionType
import com.example.localization.AppStrings
import com.example.localization.StringsProvider
import com.example.ui.MealSlot
import com.example.ui.MessUiState
import com.example.ui.components.DeveloperCreditBanner
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.TransactionCard
import com.example.ui.theme.LocalAppColors
import com.example.ui.theme.PlusJakartaFontFamily

@Composable
fun DashboardScreen(
    state: MessUiState,
    strings: AppStrings,
    onQuickAddTransaction: (TransactionType) -> Unit,
    onAdjustTodayMeal: (MealSlot, Double) -> Unit,
    onOpenMealDialog: () -> Unit,
    onEditTransaction: (MessTransaction) -> Unit,
    onDeleteTransaction: (MessTransaction) -> Unit,
    onViewAllLedger: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ext = LocalAppColors.current
    val summary = state.summary
    val lang = state.language

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Hero Personal Expense Summary Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.large)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(ext.heroStart, ext.heroEnd)
                        )
                    )
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.totalMonthlyExpenseLabel,
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = StringsProvider.formatCurrency(summary.totalMonthlyExpense, lang),
                                style = MaterialTheme.typography.displaySmall.copy(
                                    fontFamily = PlusJakartaFontFamily,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = Color.White
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(50),
                            color = ext.deposit.copy(alpha = 0.25f)
                        ) {
                            Text(
                                text = strings.personalBadge,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }

                    // 2x2 Personal Summary Metrics
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        HeroMetricTile(
                            label = strings.totalGivenDeposit,
                            value = StringsProvider.formatCurrency(summary.totalDeposit, lang),
                            accent = ext.deposit,
                            modifier = Modifier.weight(1f)
                        )
                        HeroMetricTile(
                            label = strings.totalHouseRentLabel,
                            value = StringsProvider.formatCurrency(summary.totalHouseRent, lang),
                            accent = ext.rent,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        HeroMetricTile(
                            label = strings.totalAuntyAndUtilityLabel,
                            value = StringsProvider.formatCurrency(summary.totalAuntyBill + summary.totalUtilityBill, lang),
                            accent = ext.aunty,
                            modifier = Modifier.weight(1f)
                        )
                        HeroMetricTile(
                            label = strings.totalMealsSummaryLabel,
                            value = "${StringsProvider.formatMealCount(summary.totalMeals, lang)} ${strings.mealCountSuffix}",
                            accent = ext.bazar,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 2. Quick Actions Grid (4 Personal Categories)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = strings.quickActionsTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionTile(
                        title = strings.addDepositShort,
                        icon = Icons.Outlined.Payments,
                        accent = ext.deposit,
                        testTag = "quick_add_deposit",
                        onClick = { onQuickAddTransaction(TransactionType.DEPOSIT) },
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionTile(
                        title = strings.addRentShort,
                        icon = Icons.Outlined.Home,
                        accent = ext.rent,
                        testTag = "quick_add_rent",
                        onClick = { onQuickAddTransaction(TransactionType.HOUSE_RENT) },
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionTile(
                        title = strings.addAuntyShort,
                        icon = Icons.Outlined.RestaurantMenu,
                        accent = ext.aunty,
                        testTag = "quick_add_aunty",
                        onClick = { onQuickAddTransaction(TransactionType.AUNTY_BILL) },
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionTile(
                        title = strings.addUtilityShort,
                        icon = Icons.Outlined.Bolt,
                        accent = ext.utility,
                        testTag = "quick_add_utility",
                        onClick = { onQuickAddTransaction(TransactionType.UTILITY_BILL) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 3. Today's Quick Meal Tracker Card
        item {
            TodayMealQuickCard(
                todayMeal = state.todayMeal,
                strings = strings,
                language = lang,
                onAdjustSlot = onAdjustTodayMeal,
                onOpenCustomMealDialog = onOpenMealDialog
            )
        }

        // 4. Recent Activity Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.recentEntriesTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                if (state.transactions.isNotEmpty()) {
                    TextButton(
                        onClick = onViewAllLedger,
                        modifier = Modifier.testTag("view_all_ledger_button")
                    ) {
                        Text(strings.viewAll)
                    }
                }
            }
        }

        if (state.transactions.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Outlined.ReceiptLong,
                    title = strings.noEntriesYet,
                    subtitle = strings.noEntriesHint
                )
            }
        } else {
            items(state.transactions.take(5), key = { it.id }) { tx ->
                TransactionCard(
                    transaction = tx,
                    strings = strings,
                    language = lang,
                    onEdit = { onEditTransaction(tx) },
                    onDelete = { onDeleteTransaction(tx) }
                )
            }
        }

        // 5. Developer Credit Card
        item {
            DeveloperCreditBanner(
                strings = strings,
                onClick = onOpenSettings
            )
        }
    }
}

@Composable
private fun HeroMetricTile(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = Color.White.copy(alpha = 0.11f)
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(accent)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = PlusJakartaFontFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun QuickActionTile(
    title: String,
    icon: ImageVector,
    accent: Color,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, LocalAppColors.current.cardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accent,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun TodayMealQuickCard(
    todayMeal: DailyMeal?,
    strings: AppStrings,
    language: AppLanguage,
    onAdjustSlot: (MealSlot, Double) -> Unit,
    onOpenCustomMealDialog: () -> Unit
) {
    val breakfast = todayMeal?.breakfast ?: 0.0
    val lunch = todayMeal?.lunch ?: 0.0
    val dinner = todayMeal?.dinner ?: 0.0
    val total = todayMeal?.totalMeals ?: 0.0

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, LocalAppColors.current.cardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = strings.todayMealTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${strings.totalMealsToday}: ${StringsProvider.formatMealCount(total, language)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = LocalAppColors.current.bazar
                    )
                }
                TextButton(
                    onClick = onOpenCustomMealDialog,
                    modifier = Modifier.testTag("today_meal_custom_button")
                ) {
                    Text(strings.edit)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MealSlotMiniControl(
                    label = strings.breakfastLabel,
                    count = breakfast,
                    language = language,
                    slotTag = "breakfast",
                    onMinus = { onAdjustSlot(MealSlot.BREAKFAST, -0.5) },
                    onPlus = { onAdjustSlot(MealSlot.BREAKFAST, 0.5) },
                    modifier = Modifier.weight(1f)
                )
                MealSlotMiniControl(
                    label = strings.lunchLabel,
                    count = lunch,
                    language = language,
                    slotTag = "lunch",
                    onMinus = { onAdjustSlot(MealSlot.LUNCH, -1.0) },
                    onPlus = { onAdjustSlot(MealSlot.LUNCH, 1.0) },
                    modifier = Modifier.weight(1f)
                )
                MealSlotMiniControl(
                    label = strings.dinnerLabel,
                    count = dinner,
                    language = language,
                    slotTag = "dinner",
                    onMinus = { onAdjustSlot(MealSlot.DINNER, -1.0) },
                    onPlus = { onAdjustSlot(MealSlot.DINNER, 1.0) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MealSlotMiniControl(
    label: String,
    count: Double,
    language: AppLanguage,
    slotTag: String,
    onMinus: () -> Unit,
    onPlus: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                FilledTonalIconButton(
                    onClick = onMinus,
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("today_${slotTag}_minus")
                ) {
                    Icon(Icons.Outlined.Remove, contentDescription = "Decrease $label", modifier = Modifier.size(16.dp))
                }
                Text(
                    text = StringsProvider.formatMealCount(count, language),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                FilledTonalIconButton(
                    onClick = onPlus,
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("today_${slotTag}_plus")
                ) {
                    Icon(Icons.Outlined.Add, contentDescription = "Increase $label", modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
