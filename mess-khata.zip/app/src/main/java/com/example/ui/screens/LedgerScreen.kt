package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.MessTransaction
import com.example.data.model.TransactionType
import com.example.localization.AppStrings
import com.example.localization.StringsProvider
import com.example.ui.MessUiState
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.TransactionCard
import com.example.ui.theme.LocalAppColors
import com.example.ui.theme.PlusJakartaFontFamily

@Composable
fun LedgerScreen(
    state: MessUiState,
    strings: AppStrings,
    onSelectFilter: (TransactionType?) -> Unit,
    onEditTransaction: (MessTransaction) -> Unit,
    onDeleteTransaction: (MessTransaction) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = state.language
    val filtered = state.filteredTransactions
    val filteredSum = filtered.sumOf { it.amount }

    Column(modifier = modifier.fillMaxSize()) {
        // Category Filter Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = state.categoryFilter == null,
                onClick = { onSelectFilter(null) },
                label = { Text(strings.catAll) },
                modifier = Modifier.testTag("filter_all")
            )
            TransactionType.entries.forEach { type ->
                FilterChip(
                    selected = state.categoryFilter == type,
                    onClick = { onSelectFilter(type) },
                    label = { Text(StringsProvider.categoryName(type, strings)) },
                    modifier = Modifier.testTag("filter_${type.name.lowercase()}")
                )
            }
        }

        // Filtered Summary Strip
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, LocalAppColors.current.cardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${StringsProvider.toLocalizedDigits(filtered.size.toString(), lang)} ${strings.entriesCountLabel}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${strings.filteredTotalLabel}: ",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = StringsProvider.formatCurrency(filteredSum, lang),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = PlusJakartaFontFamily,
                            fontWeight = FontWeight.Bold
                        ),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (filtered.isEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    EmptyStateCard(
                        icon = Icons.Outlined.ReceiptLong,
                        title = strings.noEntriesYet,
                        subtitle = strings.noEntriesHint
                    )
                }
            } else {
                items(filtered, key = { it.id }) { tx ->
                    TransactionCard(
                        transaction = tx,
                        strings = strings,
                        language = lang,
                        onEdit = { onEditTransaction(tx) },
                        onDelete = { onDeleteTransaction(tx) }
                    )
                }
            }
        }
    }
}
