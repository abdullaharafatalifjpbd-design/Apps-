package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.AppThemeMode
import com.example.data.model.DailyMeal
import com.example.data.model.MessTransaction
import com.example.data.model.PaymentStatus
import com.example.data.model.TransactionType
import com.example.localization.AppStrings
import com.example.localization.StringsProvider
import com.example.ui.theme.LocalAppColors
import java.util.Calendar
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TransactionEditorDialog(
    initialTransaction: MessTransaction?,
    initialType: TransactionType,
    defaultYear: Int,
    defaultMonth: Int,
    strings: AppStrings,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        type: TransactionType,
        amount: Double,
        year: Int,
        month: Int,
        day: Int,
        timestampMillis: Long,
        title: String,
        note: String,
        status: PaymentStatus
    ) -> Unit
) {
    val nowCal = Calendar.getInstance()
    val initYear = initialTransaction?.year ?: defaultYear
    val initMonth = initialTransaction?.month ?: defaultMonth
    val initDay = initialTransaction?.day ?: nowCal.get(Calendar.DAY_OF_MONTH).coerceAtMost(28)
    val initTimeMillis = initialTransaction?.timestampMillis ?: nowCal.timeInMillis
    val initCal = Calendar.getInstance().apply { timeInMillis = initTimeMillis }

    var selectedType by remember { mutableStateOf(initialTransaction?.type ?: initialType) }
    var amountText by remember {
        mutableStateOf(
            if (initialTransaction != null) {
                if (initialTransaction.amount % 1.0 == 0.0) initialTransaction.amount.toInt().toString()
                else initialTransaction.amount.toString()
            } else ""
        )
    }
    var titleText by remember {
        mutableStateOf(
            initialTransaction?.title ?: StringsProvider.presetTitle(selectedType, strings)
        )
    }
    var noteText by remember { mutableStateOf(initialTransaction?.note ?: "") }
    var selectedStatus by remember {
        mutableStateOf(
            initialTransaction?.status ?: if (selectedType == TransactionType.AUNTY_BILL) {
                PaymentStatus.CHECKED
            } else {
                PaymentStatus.PAID
            }
        )
    }

    var year by remember { mutableIntStateOf(initYear) }
    var month by remember { mutableIntStateOf(initMonth) }
    var day by remember { mutableIntStateOf(initDay) }
    var hour by remember { mutableIntStateOf(initCal.get(Calendar.HOUR_OF_DAY)) }
    var minute by remember { mutableIntStateOf(initCal.get(Calendar.MINUTE)) }

    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val timePreviewCal = remember(year, month, day, hour, minute) {
        Calendar.getInstance().apply {
            set(year, month - 1, day, hour, minute, 0)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialTransaction == null) strings.addTransactionTitle else strings.editTransactionTitle,
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = strings.categoryLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TransactionType.entries.forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = {
                                val prevPreset = StringsProvider.presetTitle(selectedType, strings)
                                selectedType = type
                                if (titleText.isBlank() || titleText == prevPreset) {
                                    titleText = StringsProvider.presetTitle(type, strings)
                                }
                                if (initialTransaction == null) {
                                    selectedStatus = if (type == TransactionType.AUNTY_BILL) {
                                        PaymentStatus.CHECKED
                                    } else {
                                        PaymentStatus.PAID
                                    }
                                }
                            },
                            label = { Text(StringsProvider.categoryName(type, strings)) },
                            modifier = Modifier.testTag("tx_type_${type.name.lowercase()}")
                        )
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        errorMsg = null
                    },
                    label = { Text(strings.amountLabel) },
                    placeholder = { Text(strings.amountHint) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tx_amount_input")
                )

                OutlinedTextField(
                    value = titleText,
                    onValueChange = {
                        titleText = it
                        errorMsg = null
                    },
                    label = { Text(strings.titleLabel) },
                    placeholder = { Text(strings.titleHint) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tx_title_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { showDatePicker = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tx_date_picker_button")
                    ) {
                        Icon(Icons.Outlined.CalendarMonth, contentDescription = strings.dateLabel, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = StringsProvider.formatShortDate(year, month, day, language),
                            maxLines = 1
                        )
                    }

                    OutlinedButton(
                        onClick = { showTimePicker = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tx_time_picker_button")
                    ) {
                        Icon(Icons.Outlined.Schedule, contentDescription = strings.timeLabel, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = StringsProvider.formatTime(timePreviewCal.timeInMillis, language),
                            maxLines = 1
                        )
                    }
                }

                Text(
                    text = strings.statusLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PaymentStatus.entries.forEach { st ->
                        FilterChip(
                            selected = selectedStatus == st,
                            onClick = { selectedStatus = st },
                            label = { Text(StringsProvider.statusName(st, strings)) },
                            modifier = Modifier.testTag("tx_status_${st.name.lowercase()}")
                        )
                    }
                }

                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text(strings.noteLabel) },
                    placeholder = { Text(strings.noteHint) },
                    maxLines = 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tx_note_input")
                )

                if (errorMsg != null) {
                    Text(
                        text = errorMsg!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val normalizedAmount = amountText.trim().replace(",", "")
                    val parsed = normalizedAmount.toDoubleOrNull()
                    if (parsed == null || parsed <= 0.0) {
                        errorMsg = strings.invalidAmountError
                        return@Button
                    }
                    if (titleText.isBlank()) {
                        errorMsg = strings.emptyTitleError
                        return@Button
                    }
                    onSave(
                        initialTransaction?.id ?: 0L,
                        selectedType,
                        parsed,
                        year,
                        month,
                        day,
                        timePreviewCal.timeInMillis,
                        titleText,
                        noteText,
                        selectedStatus
                    )
                },
                modifier = Modifier.testTag("tx_save_button")
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("tx_cancel_button")
            ) {
                Text(strings.cancel)
            }
        }
    )

    if (showDatePicker) {
        val utcCal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            clear()
            set(year, month - 1, day)
        }
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = utcCal.timeInMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { millis ->
                            val picked = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                                timeInMillis = millis
                            }
                            year = picked.get(Calendar.YEAR)
                            month = picked.get(Calendar.MONTH) + 1
                            day = picked.get(Calendar.DAY_OF_MONTH)
                        }
                        showDatePicker = false
                    }
                ) {
                    Text(strings.save)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text(strings.cancel)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    if (showTimePicker) {
        val timeState = rememberTimePickerState(initialHour = hour, initialMinute = minute, is24Hour = false)
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            title = { Text(strings.timeLabel) },
            text = { TimePicker(state = timeState) },
            confirmButton = {
                TextButton(
                    onClick = {
                        hour = timeState.hour
                        minute = timeState.minute
                        showTimePicker = false
                    }
                ) {
                    Text(strings.save)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) {
                    Text(strings.cancel)
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MealEditorDialog(
    initialMeal: DailyMeal?,
    defaultYear: Int,
    defaultMonth: Int,
    strings: AppStrings,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (year: Int, month: Int, day: Int, breakfast: Double, lunch: Double, dinner: Double, note: String) -> Unit
) {
    val nowCal = Calendar.getInstance()
    var year by remember { mutableIntStateOf(initialMeal?.year ?: defaultYear) }
    var month by remember { mutableIntStateOf(initialMeal?.month ?: defaultMonth) }
    var day by remember {
        mutableIntStateOf(
            initialMeal?.day ?: nowCal.get(Calendar.DAY_OF_MONTH).coerceAtMost(28)
        )
    }
    var breakfast by remember { mutableDoubleStateOf(initialMeal?.breakfast ?: 0.5) }
    var lunch by remember { mutableDoubleStateOf(initialMeal?.lunch ?: 1.0) }
    var dinner by remember { mutableDoubleStateOf(initialMeal?.dinner ?: 1.0) }
    var note by remember { mutableStateOf(initialMeal?.note ?: "") }
    var showDatePicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = strings.addMealDialogTitle, style = MaterialTheme.typography.titleLarge)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { showDatePicker = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("meal_date_picker_button")
                ) {
                    Icon(Icons.Outlined.CalendarMonth, contentDescription = strings.dateLabel)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(StringsProvider.formatDate(year, month, day, language))
                }

                MealStepperRow(
                    label = strings.breakfastLabel,
                    value = breakfast,
                    language = language,
                    testTagPrefix = "meal_breakfast",
                    onChange = { breakfast = it }
                )
                MealStepperRow(
                    label = strings.lunchLabel,
                    value = lunch,
                    language = language,
                    testTagPrefix = "meal_lunch",
                    onChange = { lunch = it }
                )
                MealStepperRow(
                    label = strings.dinnerLabel,
                    value = dinner,
                    language = language,
                    testTagPrefix = "meal_dinner",
                    onChange = { dinner = it }
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.pdfColTotal,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "${StringsProvider.formatMealCount(breakfast + lunch + dinner, language)} ${strings.mealCountSuffix}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(strings.noteLabel) },
                    placeholder = { Text(strings.mealNoteHint) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("meal_note_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(year, month, day, breakfast, lunch, dinner, note) },
                modifier = Modifier.testTag("meal_save_button")
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("meal_cancel_button")
            ) {
                Text(strings.cancel)
            }
        }
    )

    if (showDatePicker) {
        val utcCal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            clear()
            set(year, month - 1, day)
        }
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = utcCal.timeInMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { millis ->
                            val picked = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                                timeInMillis = millis
                            }
                            year = picked.get(Calendar.YEAR)
                            month = picked.get(Calendar.MONTH) + 1
                            day = picked.get(Calendar.DAY_OF_MONTH)
                        }
                        showDatePicker = false
                    }
                ) {
                    Text(strings.save)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text(strings.cancel)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@Composable
private fun MealStepperRow(
    label: String,
    value: Double,
    language: AppLanguage,
    testTagPrefix: String,
    onChange: (Double) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        border = BorderStroke(1.dp, LocalAppColors.current.cardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalIconButton(
                    onClick = { onChange((value - 0.5).coerceAtLeast(0.0)) },
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("${testTagPrefix}_minus")
                ) {
                    Icon(Icons.Outlined.Remove, contentDescription = "Decrease $label")
                }
                Text(
                    text = StringsProvider.formatMealCount(value, language),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                FilledTonalIconButton(
                    onClick = { onChange((value + 0.5).coerceAtMost(20.0)) },
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("${testTagPrefix}_plus")
                ) {
                    Icon(Icons.Outlined.Add, contentDescription = "Increase $label")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsAboutDialog(
    messName: String,
    language: AppLanguage,
    themeMode: AppThemeMode,
    strings: AppStrings,
    onUpdateMessName: (String) -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSelectTheme: (AppThemeMode) -> Unit,
    onDismiss: () -> Unit
) {
    var nameInput by remember(messName) { mutableStateOf(messName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.settingsTitle, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                        .padding(12.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.brand_logo),
                        contentDescription = stringResource(id = R.string.logo_content_description),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = strings.appTitle,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = strings.developerCreditDual,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text(strings.accountNameLabel) },
                    placeholder = { Text(strings.accountNameHint) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_mess_name_input")
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Language / ভাষা",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = language == AppLanguage.BENGALI,
                            onClick = { onSelectLanguage(AppLanguage.BENGALI) },
                            label = { Text("বাংলা") },
                            modifier = Modifier.testTag("settings_lang_bn")
                        )
                        FilterChip(
                            selected = language == AppLanguage.ENGLISH,
                            onClick = { onSelectLanguage(AppLanguage.ENGLISH) },
                            label = { Text("English") },
                            modifier = Modifier.testTag("settings_lang_en")
                        )
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = strings.themeLabel,
                        style = MaterialTheme.typography.labelLarge
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = themeMode == mode,
                                onClick = { onSelectTheme(mode) },
                                label = { Text(StringsProvider.themeLabel(mode, strings)) },
                                modifier = Modifier.testTag("settings_theme_${mode.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onUpdateMessName(nameInput)
                    onDismiss()
                },
                modifier = Modifier.testTag("settings_save_button")
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.close)
            }
        }
    )
}
