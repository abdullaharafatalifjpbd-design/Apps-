package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class AppExtendedColors(
    val bazar: Color,
    val deposit: Color,
    val rent: Color,
    val aunty: Color,
    val utility: Color,
    val positive: Color,
    val negative: Color,
    val heroStart: Color,
    val heroEnd: Color,
    val cardBorder: Color
)

private val LightExtendedColors = AppExtendedColors(
    bazar = BazarAmber,
    deposit = DepositSky,
    rent = RentEmerald,
    aunty = AuntyViolet,
    utility = UtilityTeal,
    positive = RentEmerald,
    negative = ExpenseCoral,
    heroStart = BrandNavyDeep,
    heroEnd = Color(0xFF0D326D),
    cardBorder = LightOutline
)

private val DarkExtendedColors = AppExtendedColors(
    bazar = BazarAmberDark,
    deposit = DepositSkyDark,
    rent = RentEmeraldDark,
    aunty = AuntyVioletDark,
    utility = UtilityTealDark,
    positive = RentEmeraldDark,
    negative = ExpenseCoralDark,
    heroStart = Color(0xFF0A1F44),
    heroEnd = Color(0xFF133B7C),
    cardBorder = DarkOutline
)

val LocalAppColors = staticCompositionLocalOf { LightExtendedColors }

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF4DA3FF),
    onPrimary = BrandNavyDeep,
    primaryContainer = Color(0xFF12366B),
    onPrimaryContainer = Color(0xFFD6E9FF),
    secondary = RentEmeraldDark,
    onSecondary = BrandNavyDeep,
    secondaryContainer = Color(0xFF0F3D31),
    onSecondaryContainer = Color(0xFFA7F3D0),
    tertiary = BazarAmberDark,
    onTertiary = BrandNavyDeep,
    tertiaryContainer = Color(0xFF452E06),
    onTertiaryContainer = Color(0xFFFDE68A),
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = DarkOutline,
    error = ExpenseCoralDark,
    onError = BrandNavyDeep
)

private val LightColorScheme = lightColorScheme(
    primary = BrandCobalt,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCEBFF),
    onPrimaryContainer = BrandNavyDeep,
    secondary = RentEmerald,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD1FAE5),
    onSecondaryContainer = Color(0xFF064E3B),
    tertiary = BazarAmber,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFEF3C7),
    onTertiaryContainer = Color(0xFF78350F),
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    outline = LightOutline,
    error = ExpenseCoral,
    onError = Color.White
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MessKhataTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val extendedColors = if (darkTheme) DarkExtendedColors else LightExtendedColors

    CompositionLocalProvider(LocalAppColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = AppShapes,
            content = content
        )
    }
}
