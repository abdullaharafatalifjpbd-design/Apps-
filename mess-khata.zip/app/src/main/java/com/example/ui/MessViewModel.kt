package com.example.ui

import android.content.Context
import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppLanguage
import com.example.data.model.AppThemeMode
import com.example.data.model.DailyMeal
import com.example.data.model.MessTransaction
import com.example.data.model.MonthSummary
import com.example.data.model.PaymentStatus
import com.example.data.model.TransactionType
import com.example.data.repository.MessRepository
import com.example.data.repository.UserPreferencesRepository
import com.example.pdf.MonthlyPdfGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

enum class MealSlot {
    BREAKFAST,
    LUNCH,
    DINNER
}

sealed interface PdfGenerationState {
    data object Idle : PdfGenerationState
    data object Generating : PdfGenerationState
    data class Ready(
        val file: File,
        val pageCount: Int,
        val previewPages: List<Bitmap>,
        val generatedMonthKey: Int
    ) : PdfGenerationState
    data class Error(val message: String) : PdfGenerationState
}

data class MessUiState(
    val selectedYear: Int = Calendar.getInstance().get(Calendar.YEAR),
    val selectedMonth: Int = Calendar.getInstance().get(Calendar.MONTH) + 1,
    val language: AppLanguage = AppLanguage.BENGALI,
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val messName: String = "",
    val transactions: List<MessTransaction> = emptyList(),
    val meals: List<DailyMeal> = emptyList(),
    val summary: MonthSummary = MonthSummary.calculate(
        Calendar.getInstance().get(Calendar.YEAR),
        Calendar.getInstance().get(Calendar.MONTH) + 1,
        emptyList(),
        emptyList()
    ),
    val todayMeal: DailyMeal? = null,
    val categoryFilter: TransactionType? = null,
    val pdfState: PdfGenerationState = PdfGenerationState.Idle
) {
    val filteredTransactions: List<MessTransaction>
        get() = if (categoryFilter == null) transactions else transactions.filter { it.type == categoryFilter }
}

@OptIn(ExperimentalCoroutinesApi::class)
class MessViewModel(
    private val repository: MessRepository,
    private val preferences: UserPreferencesRepository
) : ViewModel() {

    private val initialCal = Calendar.getInstance()
    private val selectedYearMonth = MutableStateFlow(
        initialCal.get(Calendar.YEAR) to (initialCal.get(Calendar.MONTH) + 1)
    )
    private val categoryFilter = MutableStateFlow<TransactionType?>(null)
    private val pdfState = MutableStateFlow<PdfGenerationState>(PdfGenerationState.Idle)

    private val monthTransactionsFlow = selectedYearMonth.flatMapLatest { (year, month) ->
        repository.observeTransactionsForMonth(year, month)
    }

    private val monthMealsFlow = selectedYearMonth.flatMapLatest { (year, month) ->
        repository.observeMealsForMonth(year, month)
    }

    private val preferencesFlow = combine(
        preferences.languageFlow,
        preferences.themeModeFlow,
        preferences.messNameFlow
    ) { lang, theme, messName ->
        Triple(lang, theme, messName)
    }

    val uiState: StateFlow<MessUiState> = combine(
        selectedYearMonth,
        monthTransactionsFlow,
        monthMealsFlow,
        preferencesFlow,
        categoryFilter,
        pdfState
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val ym = values[0] as Pair<Int, Int>
        @Suppress("UNCHECKED_CAST")
        val transactions = values[1] as List<MessTransaction>
        @Suppress("UNCHECKED_CAST")
        val meals = values[2] as List<DailyMeal>
        @Suppress("UNCHECKED_CAST")
        val prefs = values[3] as Triple<AppLanguage, AppThemeMode, String>
        val filter = values[4] as TransactionType?
        val pdf = values[5] as PdfGenerationState

        val (year, month) = ym
        val now = Calendar.getInstance()
        val todayKey = DailyMeal.makeDateKey(
            now.get(Calendar.YEAR),
            now.get(Calendar.MONTH) + 1,
            now.get(Calendar.DAY_OF_MONTH)
        )
        val todayMeal = meals.firstOrNull { it.dateKey == todayKey }
        val summary = MonthSummary.calculate(year, month, transactions, meals)

        val currentMonthKey = year * 100 + month
        val validPdfState = if (pdf is PdfGenerationState.Ready && pdf.generatedMonthKey != currentMonthKey) {
            PdfGenerationState.Idle
        } else {
            pdf
        }

        MessUiState(
            selectedYear = year,
            selectedMonth = month,
            language = prefs.first,
            themeMode = prefs.second,
            messName = prefs.third,
            transactions = transactions,
            meals = meals,
            summary = summary,
            todayMeal = todayMeal,
            categoryFilter = filter,
            pdfState = validPdfState
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = MessUiState()
    )

    fun previousMonth() {
        val (year, month) = selectedYearMonth.value
        selectedYearMonth.value = if (month == 1) (year - 1) to 12 else year to (month - 1)
    }

    fun nextMonth() {
        val (year, month) = selectedYearMonth.value
        selectedYearMonth.value = if (month == 12) (year + 1) to 1 else year to (month + 1)
    }

    fun toggleLanguage() {
        val next = if (uiState.value.language == AppLanguage.BENGALI) AppLanguage.ENGLISH else AppLanguage.BENGALI
        viewModelScope.launch {
            preferences.setLanguage(next)
            pdfState.value = PdfGenerationState.Idle
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            preferences.setLanguage(language)
            pdfState.value = PdfGenerationState.Idle
        }
    }

    fun toggleTheme(currentlyDark: Boolean) {
        val next = if (currentlyDark) AppThemeMode.LIGHT else AppThemeMode.DARK
        viewModelScope.launch {
            preferences.setThemeMode(next)
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch {
            preferences.setThemeMode(mode)
        }
    }

    fun updateMessName(name: String) {
        viewModelScope.launch {
            preferences.setMessName(name)
        }
    }

    fun setCategoryFilter(type: TransactionType?) {
        categoryFilter.value = type
    }

    fun saveTransaction(
        id: Long = 0L,
        type: TransactionType,
        amount: Double,
        year: Int,
        month: Int,
        day: Int,
        timestampMillis: Long,
        title: String,
        note: String,
        status: PaymentStatus
    ) {
        viewModelScope.launch {
            repository.saveTransaction(
                MessTransaction(
                    id = id,
                    type = type,
                    amount = amount,
                    year = year,
                    month = month,
                    day = day,
                    timestampMillis = timestampMillis,
                    title = title.trim(),
                    note = note.trim(),
                    status = status
                )
            )
            // Jump to the saved entry's month so the user always sees what they just added
            selectedYearMonth.value = year to month
            pdfState.value = PdfGenerationState.Idle
        }
    }

    fun deleteTransaction(id: Long) {
        viewModelScope.launch {
            repository.deleteTransaction(id)
            pdfState.value = PdfGenerationState.Idle
        }
    }

    fun saveMeal(
        year: Int,
        month: Int,
        day: Int,
        breakfast: Double,
        lunch: Double,
        dinner: Double,
        note: String
    ) {
        viewModelScope.launch {
            val dateKey = DailyMeal.makeDateKey(year, month, day)
            repository.saveMeal(
                DailyMeal(
                    dateKey = dateKey,
                    year = year,
                    month = month,
                    day = day,
                    breakfast = breakfast.coerceAtLeast(0.0),
                    lunch = lunch.coerceAtLeast(0.0),
                    dinner = dinner.coerceAtLeast(0.0),
                    note = note.trim()
                )
            )
            selectedYearMonth.value = year to month
            pdfState.value = PdfGenerationState.Idle
        }
    }

    fun adjustTodayMeal(slot: MealSlot, delta: Double) {
        viewModelScope.launch {
            val now = Calendar.getInstance()
            val y = now.get(Calendar.YEAR)
            val m = now.get(Calendar.MONTH) + 1
            val d = now.get(Calendar.DAY_OF_MONTH)
            val existing = repository.getMealForDate(y, m, d) ?: DailyMeal(
                dateKey = DailyMeal.makeDateKey(y, m, d),
                year = y,
                month = m,
                day = d
            )
            val updated = when (slot) {
                MealSlot.BREAKFAST -> existing.copy(breakfast = (existing.breakfast + delta).coerceIn(0.0, 20.0))
                MealSlot.LUNCH -> existing.copy(lunch = (existing.lunch + delta).coerceIn(0.0, 20.0))
                MealSlot.DINNER -> existing.copy(dinner = (existing.dinner + delta).coerceIn(0.0, 20.0))
            }
            repository.saveMeal(updated)
            pdfState.value = PdfGenerationState.Idle
        }
    }

    fun deleteMeal(dateKey: Int) {
        viewModelScope.launch {
            repository.deleteMeal(dateKey)
            pdfState.value = PdfGenerationState.Idle
        }
    }

    fun generateMonthlyPdf(context: Context) {
        val snapshot = uiState.value
        if (pdfState.value is PdfGenerationState.Generating) return
        pdfState.value = PdfGenerationState.Generating

        viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    MonthlyPdfGenerator.generate(
                        context = context.applicationContext,
                        language = snapshot.language,
                        accountName = snapshot.messName,
                        summary = snapshot.summary,
                        transactions = snapshot.transactions,
                        meals = snapshot.meals
                    )
                }
                val monthKey = snapshot.selectedYear * 100 + snapshot.selectedMonth
                pdfState.value = PdfGenerationState.Ready(
                    file = result.file,
                    pageCount = result.pageCount,
                    previewPages = result.previewPages,
                    generatedMonthKey = monthKey
                )
            } catch (e: Exception) {
                pdfState.value = PdfGenerationState.Error(e.localizedMessage ?: "PDF error")
            }
        }
    }
}
