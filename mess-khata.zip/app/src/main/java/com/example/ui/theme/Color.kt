package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Core (aligned with Mess Khata Logo)
val BrandNavyDeep = Color(0xFF011636)
val BrandNavySurface = Color(0xFF0B1F3F)
val BrandCobalt = Color(0xFF0066E6)
val BrandSkyBlue = Color(0xFF38BDF8)

// Category Accents
val BazarAmber = Color(0xFFF59E0B)
val BazarAmberDark = Color(0xFFFBBF24)
val DepositSky = Color(0xFF0284C7)
val DepositSkyDark = Color(0xFF38BDF8)
val RentEmerald = Color(0xFF10B981)
val RentEmeraldDark = Color(0xFF34D399)
val AuntyViolet = Color(0xFF7C3AED)
val AuntyVioletDark = Color(0xFFA78BFA)
val UtilityTeal = Color(0xFF0D9488)
val UtilityTealDark = Color(0xFF2DD4BF)
val ExpenseCoral = Color(0xFFEF4444)
val ExpenseCoralDark = Color(0xFFF87171)

// Light Theme Tokens
val LightBackground = Color(0xFFF3F6FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE6EDF7)
val LightOutline = Color(0xFFCBD5E1)
val LightOnBackground = Color(0xFF0B192C)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)

// Dark Theme Tokens
val DarkBackground = Color(0xFF061021)
val DarkSurface = Color(0xFF0E1C34)
val DarkSurfaceVariant = Color(0xFF162947)
val DarkOutline = Color(0xFF263B5E)
val DarkOnBackground = Color(0xFFF1F5F9)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
