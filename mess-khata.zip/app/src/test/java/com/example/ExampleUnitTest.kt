package com.example

import com.example.data.model.AppLanguage
import com.example.data.model.DailyMeal
import com.example.data.model.MessTransaction
import com.example.data.model.MonthSummary
import com.example.data.model.PaymentStatus
import com.example.data.model.TransactionType
import com.example.localization.StringsProvider
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun `monthly summary calculates personal expenses and meal totals accurately`() {
    val transactions = listOf(
      MessTransaction(1, TransactionType.DEPOSIT, 4000.0, 2026, 11, 2, 1000L, "Deposit"),
      MessTransaction(2, TransactionType.HOUSE_RENT, 5500.0, 2026, 11, 7, 1000L, "Rent", status = PaymentStatus.PAID),
      MessTransaction(3, TransactionType.AUNTY_BILL, 1200.0, 2026, 11, 10, 1000L, "Aunty", status = PaymentStatus.CHECKED),
      MessTransaction(4, TransactionType.UTILITY_BILL, 500.0, 2026, 11, 12, 1000L, "Wifi")
    )
    val meals = listOf(
      DailyMeal(20261101, 2026, 11, 1, breakfast = 1.0, lunch = 1.0, dinner = 1.0),
      DailyMeal(20261102, 2026, 11, 2, breakfast = 0.0, lunch = 1.0, dinner = 1.0)
    )

    val summary = MonthSummary.calculate(2026, 11, transactions, meals)

    assertEquals(4000.0, summary.totalDeposit, 0.001)
    assertEquals(5500.0, summary.totalHouseRent, 0.001)
    assertEquals(1200.0, summary.totalAuntyBill, 0.001)
    assertEquals(500.0, summary.totalUtilityBill, 0.001)
    assertEquals(11200.0, summary.totalMonthlyExpense, 0.001)
    assertEquals(5.0, summary.totalMeals, 0.001)
    assertEquals(2, summary.mealDaysCount)
  }

  @Test
  fun `bilingual strings, app title, and credit lines are accurate`() {
    val bn = StringsProvider.get(AppLanguage.BENGALI)
    val en = StringsProvider.get(AppLanguage.ENGLISH)
    assertEquals("Monthly Expenses", bn.appTitle)
    assertEquals("Monthly Expenses", en.appTitle)
    assertEquals("ডিজাইন আব্দুল্লাহ", bn.developerCredit)
    assertEquals("Design By Abdullah", en.developerCredit)
    assertEquals("৳১,৫০০", StringsProvider.formatCurrency(1500.0, AppLanguage.BENGALI))
    assertEquals("৳1,500", StringsProvider.formatCurrency(1500.0, AppLanguage.ENGLISH))
    assertEquals("২৪ নভেম্বর (মঙ্গলবার)", StringsProvider.formatDateWithDay(2026, 11, 24, AppLanguage.BENGALI))
    assertEquals("24 Nov (Tue)", StringsProvider.formatDateWithDay(2026, 11, 24, AppLanguage.ENGLISH))
  }
}
