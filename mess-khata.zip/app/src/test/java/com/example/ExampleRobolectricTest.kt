package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read app name and developer credit from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals("Monthly Expenses", context.getString(R.string.app_name))
    assertEquals("Design By Abdullah", context.getString(R.string.brand_credit_en))
    assertEquals("ডিজাইন আব্দুল্লাহ", context.getString(R.string.brand_credit_bn))
  }
}
